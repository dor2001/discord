# Discord Music Bot • Spotify-like Web Panel (v3.1)
- ייבוא פלייליסטים **מיוטיוב** אל פלייליסט פנימי
- המלצות לפי **ז׳אנרים מועדפים** + **היסטוריית האזנה** (data/history.json)
- כל מה שב-v3: UI בסגנון Spotify, Drag & Drop, Repeat/Shuffle, Settings Persist, Live Announce, Dynamic Voice

## שימוש מהפאנל
- ייבוא: הזן YouTube Playlist URL + שם יעד → "ייבא".
- המלצות: "רענן" תחת "המלצות בשבילי".

## פקודות חדשות
- `/import url:<YT playlist URL> name:<שם>` (Admin)
- `/recommend limit:<כמות>` – שולח הצעות לפאנל.
